Swindon Urban Green Network - Supplementary GIS Bundles (2026 Baseline, Public Copy)
===================================================================================

Source working generation: rev 3256
Bundle 1 (Parcels & Network):  swindon-green-network-gis-parcels-2026.zip
Bundle 2 (Habitats & Gardens): swindon-green-network-gis-habitats-2026.zip

GeoPackage 1: swindon_green_network_2026_bng27700.gpkg (EPSG:27700 British National Grid):
  1. proposed_parcels_whole     (1165 features) - Joined whole parcels PR-0001..PR-1208 with descriptions and OS Grid Refs
  2. proposed_segments_typed    (1474 features) - Constituent typed segments PR-xxxx-Sxx (user-locked 9-type classification)
  3. existing_en1               (40 features) - Existing EN1 green corridor baseline polygons
  4. existing_green_space       (23 features) - Existing designated green space and community open space polygons (restricted species zones omitted)
  5. urban_review_zones         (5 features) - Five urban Swindon review zone boundaries

GeoPackage 2: swindon_habitats_and_gardens_2026_bng27700.gpkg (EPSG:27700 British National Grid):
  1. mapped_physical_habitat    (4574 features) - Indicative physical habitat polygons across the 6 green habitat groups (matching Figures 8 and 10; no formal accuracy audit)
  2. residential_garden_blocks  (1338 features) - Indicative Sentinel-2 10m NDVI residential block garden estimates (matching Figure 9; context only)

Universal WGS84 GeoJSON Files (in Parcels Bundle, RFC 7946, EPSG:4326):
  - swindon_proposed_parcels_whole.geojson
  - swindon_proposed_segments_typed.geojson

Spreadsheet / Officer Lookup Table (in Parcels Bundle):
  - swindon_parcel_inventory_by_pr.csv (one row per PR-xxxx parcel with OS Grid Ref, Easting/Northing, Lat/Lon, habitat, nearest EN1/designated green space distance/direction, and prose description)

Notes on Interpretation:
  - Numbering uses a two-layer scheme: PR-xxxx denotes the whole spatial unit; PR-xxxx-Sxx denotes constituent land-character segments where a parcel spans more than one parcel type.
  - Parcel types (1 through 6b) are a broad town-scale guide to land and management character only, not site-level ecological surveys.
  - No site inspection has been made; parcel extent, overlapping features, and definitions are derived from OpenStreetMap (OSM) and desktop GIS layers.
  - Mapped paths, playing fields, playgrounds, allotments, water, and benches are noted only where recorded inside a parcel.
  - Sensitive species locations and personal submitter details are withheld from this public copy.
